#!/bin/bash
set -e
pegasus_lite_version_major="5"
pegasus_lite_version_minor="0"
pegasus_lite_version_patch="1"
pegasus_lite_enforce_strict_wp_check="true"
pegasus_lite_version_allow_wp_auto_download="true"


. pegasus-lite-common.sh

pegasus_lite_init

# cleanup in case of failures
trap pegasus_lite_signal_int INT
trap pegasus_lite_signal_term TERM
trap pegasus_lite_unexpected_exit EXIT

printf "\n########################[Pegasus Lite] Setting up workdir ########################\n"  1>&2
# work dir
pegasus_lite_setup_work_dir

printf "\n##############[Pegasus Lite] Figuring out the worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package

printf "\n#######################[Pegasus Lite] Staging in container #######################\n"  1>&2
# stage in container file 
pegasus-transfer --threads 1  1>&2 << 'EOF'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "casa_wind_cont.sif",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///usr/bin/casa-wind_latest.sif", "priority": 100, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "symlink://$PWD/casa_wind_cont.sif", "type": "singularity" }
   ] }
]
EOF

set -e

printf "\n########[Pegasus Lite] Writing out script to launch user task in container ########\n"  1>&2

cat <<EOF > merge_top-cont.sh
#!/bin/sh
printf "\n#################[Container] Now in pegasus lite container script #################\n"  1>&2
set -e

# tmp dirs are handled by Singularity - don't use the ones from the host
unset TEMP
unset TMP
unset TMPDIR

# setting environment variables for job
HOME=/srv
export HOME
EOF
container_env /srv >> merge_top-cont.sh
cat <<EOF2 >> merge_top-cont.sh
pegasus_lite_version_major=$pegasus_lite_version_major
pegasus_lite_version_minor=$pegasus_lite_version_minor
pegasus_lite_version_patch=$pegasus_lite_version_patch
pegasus_lite_enforce_strict_wp_check=$pegasus_lite_enforce_strict_wp_check
pegasus_lite_version_allow_wp_auto_download=$pegasus_lite_version_allow_wp_auto_download
pegasus_lite_inside_container=true
pegasus_lite_work_dir=/srv

cd /srv
. ./pegasus-lite-common.sh
pegasus_lite_init

printf "\n##############[Container] Figuring out Pegasus worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package
printf "PATH in container is set to is set to \$PATH\n"  1>&2

printf "\n###################### Staging in input data and executables ######################\n"  1>&2
# stage in data and executables
pegasus-transfer --threads 1  --symlink  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "addison.tx-20170329-072251.netcdf.gz",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/addison.tx-20170329-072251.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/addison.tx-20170329-072251.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "mesquite.tx-20170329-072227.netcdf.gz",
   "id": 2,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/mesquite.tx-20170329-072227.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/mesquite.tx-20170329-072227.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "mesquite.tx-20170329-072327.netcdf.gz",
   "id": 3,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/mesquite.tx-20170329-072327.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/mesquite.tx-20170329-072327.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "cleburne.tx-20170329-072225.netcdf.gz",
   "id": 4,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/cleburne.tx-20170329-072225.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/cleburne.tx-20170329-072225.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "denton.tx-20170329-072227.netcdf.gz",
   "id": 5,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/denton.tx-20170329-072227.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/denton.tx-20170329-072227.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "mesquite.tx-20170329-072247.netcdf.gz",
   "id": 6,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/mesquite.tx-20170329-072247.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/mesquite.tx-20170329-072247.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "midlothian.tx-20170329-072310.netcdf.gz",
   "id": 7,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/midlothian.tx-20170329-072310.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/midlothian.tx-20170329-072310.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "denton.tx-20170329-072201.netcdf.gz",
   "id": 8,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/denton.tx-20170329-072201.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/denton.tx-20170329-072201.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "denton.tx-20170329-072301.netcdf.gz",
   "id": 9,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/denton.tx-20170329-072301.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/denton.tx-20170329-072301.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "arlington.tx-20170329-072235.netcdf.gz",
   "id": 10,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/arlington.tx-20170329-072235.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/arlington.tx-20170329-072235.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "cleburne.tx-20170329-072302.netcdf.gz",
   "id": 11,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/cleburne.tx-20170329-072302.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/cleburne.tx-20170329-072302.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "cleburne.tx-20170329-072326.netcdf.gz",
   "id": 12,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/cleburne.tx-20170329-072326.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/cleburne.tx-20170329-072326.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "denton.tx-20170329-072327.netcdf.gz",
   "id": 13,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/denton.tx-20170329-072327.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/denton.tx-20170329-072327.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "ftworth.tx-20170329-072231.netcdf.gz",
   "id": 14,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/ftworth.tx-20170329-072231.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/ftworth.tx-20170329-072231.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "cleburne.tx-20170329-072202.netcdf.gz",
   "id": 15,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/cleburne.tx-20170329-072202.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/cleburne.tx-20170329-072202.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "mesquite.tx-20170329-072207.netcdf.gz",
   "id": 16,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/mesquite.tx-20170329-072207.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/mesquite.tx-20170329-072207.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "midlothian.tx-20170329-072328.netcdf.gz",
   "id": 17,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/midlothian.tx-20170329-072328.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/midlothian.tx-20170329-072328.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "mesquite.tx-20170329-072307.netcdf.gz",
   "id": 18,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/mesquite.tx-20170329-072307.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/mesquite.tx-20170329-072307.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "midlothian.tx-20170329-072251.netcdf.gz",
   "id": 19,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/midlothian.tx-20170329-072251.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/midlothian.tx-20170329-072251.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "ftworth.tx-20170329-072211.netcdf.gz",
   "id": 20,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/ftworth.tx-20170329-072211.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/ftworth.tx-20170329-072211.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "arlington.tx-20170329-072255.netcdf.gz",
   "id": 21,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/arlington.tx-20170329-072255.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/arlington.tx-20170329-072255.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "arlington.tx-20170329-072315.netcdf.gz",
   "id": 22,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/arlington.tx-20170329-072315.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/arlington.tx-20170329-072315.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "midlothian.tx-20170329-072208.netcdf.gz",
   "id": 23,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/midlothian.tx-20170329-072208.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/midlothian.tx-20170329-072208.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "arlington.tx-20170329-072215.netcdf.gz",
   "id": 24,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/arlington.tx-20170329-072215.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/arlington.tx-20170329-072215.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "ftworth.tx-20170329-072311.netcdf.gz",
   "id": 25,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/ftworth.tx-20170329-072311.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/ftworth.tx-20170329-072311.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "ftworth.tx-20170329-072251.netcdf.gz",
   "id": 26,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/ftworth.tx-20170329-072251.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/ftworth.tx-20170329-072251.netcdf.gz" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "midlothian.tx-20170329-072227.netcdf.gz",
   "id": 27,
   "src_urls": [
     { "site_label": "condorpool", "url": "/home/panorama/public_html/casa-data/midlothian.tx-20170329-072227.netcdf.gz", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/midlothian.tx-20170329-072227.netcdf.gz" }
   ] }
]
eof

set +e
job_ec=0
printf "\n#########################[Container] Launching user task #########################\n"  1>&2

pegasus-cluster  -f  << CLUSTER
#@ 1 gunzip gunzip_15 
pegasus-kickstart  -n gunzip -N gunzip_15 -R condorpool  -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force midlothian.tx-20170329-072251.netcdf.gz
#@ 2 gunzip gunzip_16 
pegasus-kickstart  -n gunzip -N gunzip_16 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force arlington.tx-20170329-072255.netcdf.gz
#@ 3 gunzip gunzip_13 
pegasus-kickstart  -n gunzip -N gunzip_13 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force addison.tx-20170329-072251.netcdf.gz
#@ 4 gunzip gunzip_14 
pegasus-kickstart  -n gunzip -N gunzip_14 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force ftworth.tx-20170329-072251.netcdf.gz
#@ 5 gunzip gunzip_19 
pegasus-kickstart  -n gunzip -N gunzip_19 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force mesquite.tx-20170329-072307.netcdf.gz
#@ 6 gunzip gunzip_17 
pegasus-kickstart  -n gunzip -N gunzip_17 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force denton.tx-20170329-072301.netcdf.gz
#@ 7 gunzip gunzip_18 
pegasus-kickstart  -n gunzip -N gunzip_18 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force cleburne.tx-20170329-072302.netcdf.gz
#@ 8 gunzip gunzip_22 
pegasus-kickstart  -n gunzip -N gunzip_22 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force arlington.tx-20170329-072315.netcdf.gz
#@ 9 gunzip gunzip_23 
pegasus-kickstart  -n gunzip -N gunzip_23 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force cleburne.tx-20170329-072326.netcdf.gz
#@ 10 gunzip gunzip_20 
pegasus-kickstart  -n gunzip -N gunzip_20 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force midlothian.tx-20170329-072310.netcdf.gz
#@ 11 gunzip gunzip_21 
pegasus-kickstart  -n gunzip -N gunzip_21 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force ftworth.tx-20170329-072311.netcdf.gz
#@ 12 gunzip gunzip_26 
pegasus-kickstart  -n gunzip -N gunzip_26 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force midlothian.tx-20170329-072328.netcdf.gz
#@ 13 gunzip gunzip_24 
pegasus-kickstart  -n gunzip -N gunzip_24 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force mesquite.tx-20170329-072327.netcdf.gz
#@ 14 gunzip gunzip_25 
pegasus-kickstart  -n gunzip -N gunzip_25 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force denton.tx-20170329-072327.netcdf.gz
#@ 15 gunzip gunzip_11 
pegasus-kickstart  -n gunzip -N gunzip_11 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force arlington.tx-20170329-072235.netcdf.gz
#@ 16 gunzip gunzip_9 
pegasus-kickstart  -n gunzip -N gunzip_9 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force denton.tx-20170329-072227.netcdf.gz
#@ 17 gunzip gunzip_12 
pegasus-kickstart  -n gunzip -N gunzip_12 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force mesquite.tx-20170329-072247.netcdf.gz
#@ 18 gunzip gunzip_8 
pegasus-kickstart  -n gunzip -N gunzip_8 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force midlothian.tx-20170329-072227.netcdf.gz
#@ 19 gunzip gunzip_7 
pegasus-kickstart  -n gunzip -N gunzip_7 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force mesquite.tx-20170329-072227.netcdf.gz
#@ 20 gunzip gunzip_6 
pegasus-kickstart  -n gunzip -N gunzip_6 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force cleburne.tx-20170329-072225.netcdf.gz
#@ 21 gunzip gunzip_10 
pegasus-kickstart  -n gunzip -N gunzip_10 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force ftworth.tx-20170329-072231.netcdf.gz
#@ 22 gunzip gunzip_5 
pegasus-kickstart  -n gunzip -N gunzip_5 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force arlington.tx-20170329-072215.netcdf.gz
#@ 23 gunzip gunzip_4 
pegasus-kickstart  -n gunzip -N gunzip_4 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force ftworth.tx-20170329-072211.netcdf.gz
#@ 24 gunzip gunzip_3 
pegasus-kickstart  -n gunzip -N gunzip_3 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force midlothian.tx-20170329-072208.netcdf.gz
#@ 25 gunzip gunzip_2 
pegasus-kickstart  -n gunzip -N gunzip_2 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force mesquite.tx-20170329-072207.netcdf.gz
#@ 26 gunzip gunzip_1 
pegasus-kickstart  -n gunzip -N gunzip_1 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force cleburne.tx-20170329-072202.netcdf.gz
#@ 27 gunzip gunzip_0 
pegasus-kickstart  -n gunzip -N gunzip_0 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /bin/gunzip --force denton.tx-20170329-072201.netcdf.gz
#@ 28 um_vel um_vel 
pegasus-kickstart  -n um_vel -N um_vel -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:33+00:00 /opt/UM_VEL/UM_VEL denton.tx-20170329-072201.netcdf cleburne.tx-20170329-072202.netcdf mesquite.tx-20170329-072207.netcdf midlothian.tx-20170329-072208.netcdf ftworth.tx-20170329-072211.netcdf arlington.tx-20170329-072215.netcdf cleburne.tx-20170329-072225.netcdf mesquite.tx-20170329-072227.netcdf midlothian.tx-20170329-072227.netcdf denton.tx-20170329-072227.netcdf ftworth.tx-20170329-072231.netcdf arlington.tx-20170329-072235.netcdf mesquite.tx-20170329-072247.netcdf addison.tx-20170329-072251.netcdf ftworth.tx-20170329-072251.netcdf midlothian.tx-20170329-072251.netcdf arlington.tx-20170329-072255.netcdf denton.tx-20170329-072301.netcdf cleburne.tx-20170329-072302.netcdf mesquite.tx-20170329-072307.netcdf midlothian.tx-20170329-072310.netcdf ftworth.tx-20170329-072311.netcdf arlington.tx-20170329-072315.netcdf cleburne.tx-20170329-072326.netcdf mesquite.tx-20170329-072327.netcdf denton.tx-20170329-072327.netcdf midlothian.tx-20170329-072328.netcdf
CLUSTER
set -e
printf "\n############################ Staging out output files ############################\n"  1>&2
# stage out
pegasus-transfer --threads 1  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "output",
   "lfn": "MaxVelocity_20170329-072328.netcdf",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///srv/MaxVelocity_20170329-072328.netcdf", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "staging", "url": "scp://panorama@10.100.101.107/home/panorama/public_html//panorama/pegasus/casa-wind/run0025/00/00/MaxVelocity_20170329-072328.netcdf" }
   ] }
]
eof

printf "\n################[Container] Exiting pegasus lite container script ################\n"  1>&2
EOF2


chmod +x merge_top-cont.sh
if ! [ $pegasus_lite_start_dir -ef . ]; then
	cp $pegasus_lite_start_dir/pegasus-lite-common.sh . 
fi

set +e
singularity_init casa_wind_cont.sif
job_ec=$(($job_ec + $?))

singularity exec --no-home --bind $PWD:/srv --bind /home/panorama/public_html:/home/panorama/public_html:ro casa_wind_cont.sif /srv/merge_top-cont.sh 
job_ec=$(($job_ec + $?))


set -e


# clear the trap, and exit cleanly
trap - EXIT
pegasus_lite_final_exit

