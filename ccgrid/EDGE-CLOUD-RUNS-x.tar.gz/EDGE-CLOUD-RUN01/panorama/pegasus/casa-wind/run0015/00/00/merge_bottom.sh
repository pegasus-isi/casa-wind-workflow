#!/bin/bash
set -e
pegasus_lite_version_major="5"
pegasus_lite_version_minor="0"
pegasus_lite_version_patch="1"
pegasus_lite_enforce_strict_wp_check="true"
pegasus_lite_version_allow_wp_auto_download="true"


. pegasus-lite-common.sh

pegasus_lite_init

# cleanup in case of failures
trap pegasus_lite_signal_int INT
trap pegasus_lite_signal_term TERM
trap pegasus_lite_unexpected_exit EXIT

printf "\n########################[Pegasus Lite] Setting up workdir ########################\n"  1>&2
# work dir
pegasus_lite_setup_work_dir

printf "\n##############[Pegasus Lite] Figuring out the worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package

printf "\n#######################[Pegasus Lite] Staging in container #######################\n"  1>&2
# stage in container file 
pegasus-transfer --threads 1  1>&2 << 'EOF'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "casa_wind_cont.sif",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///usr/bin/casa-wind_latest.sif", "priority": 100, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "symlink://$PWD/casa_wind_cont.sif", "type": "singularity" }
   ] }
]
EOF

set -e

printf "\n########[Pegasus Lite] Writing out script to launch user task in container ########\n"  1>&2

cat <<EOF > merge_bottom-cont.sh
#!/bin/sh
printf "\n#################[Container] Now in pegasus lite container script #################\n"  1>&2
set -e

# tmp dirs are handled by Singularity - don't use the ones from the host
unset TEMP
unset TMP
unset TMPDIR

# setting environment variables for job
HOME=/srv
export HOME
EOF
container_env /srv >> merge_bottom-cont.sh
cat <<EOF2 >> merge_bottom-cont.sh
pegasus_lite_version_major=$pegasus_lite_version_major
pegasus_lite_version_minor=$pegasus_lite_version_minor
pegasus_lite_version_patch=$pegasus_lite_version_patch
pegasus_lite_enforce_strict_wp_check=$pegasus_lite_enforce_strict_wp_check
pegasus_lite_version_allow_wp_auto_download=$pegasus_lite_version_allow_wp_auto_download
pegasus_lite_inside_container=true
pegasus_lite_work_dir=/srv

cd /srv
. ./pegasus-lite-common.sh
pegasus_lite_init

printf "\n##############[Container] Figuring out Pegasus worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package
printf "PATH in container is set to is set to \$PATH\n"  1>&2

printf "\n###################### Staging in input data and executables ######################\n"  1>&2
# stage in data and executables
pegasus-transfer --threads 1  --symlink  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "pointAlert_config.txt",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "http://10.100.101.107/~panorama/casa-data/pointAlert_config.txt", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/pointAlert_config.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "MaxVelocity_20170329-074254.netcdf",
   "id": 2,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/casa-wind/run0015/00/00/MaxVelocity_20170329-074254.netcdf", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/MaxVelocity_20170329-074254.netcdf" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "max_wind.png",
   "id": 3,
   "src_urls": [
     { "site_label": "condorpool", "url": "http://10.100.101.107/~panorama/casa-data/max_wind.png", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/max_wind.png" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "hospital_locations.geojson",
   "id": 4,
   "src_urls": [
     { "site_label": "condorpool", "url": "http://10.100.101.107/~panorama/casa-data/hospital_locations.geojson", "priority": 50, "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file:///srv/hospital_locations.geojson" }
   ] }
]
eof

set +e
job_ec=0
printf "\n#########################[Container] Launching user task #########################\n"  1>&2

pegasus-cluster  -f  << CLUSTER
#@ 1 post_vel ID0000001 
pegasus-kickstart  -n post_vel -N ID0000001 -R condorpool  -L casa-wind -T 2021-12-01T21:30:40+00:00 /opt/netcdf2png/merged_netcdf2png -c max_wind.png -q 235 -z 11.176,38 -o MaxVelocity_20170329-074254.png MaxVelocity_20170329-074254.netcdf
#@ 2 mvt ID0000002 
pegasus-kickstart  -n mvt -N ID0000002 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:40+00:00 /opt/mvt/mvt MaxVelocity_20170329-074254.netcdf
#@ 3 point_alert ID0000003 
pegasus-kickstart  -n point_alert -N ID0000003 -R condorpool  -H -L casa-wind -T 2021-12-01T21:30:40+00:00 /opt/pointAlert/pointAlert -c pointAlert_config.txt -p -o alert_20170329-074254.geojson -g hospital_locations.geojson mvt_MaxVelocity_20170329-074254.geojson
CLUSTER
set -e
printf "\n############################ Staging out output files ############################\n"  1>&2
# stage out
pegasus-transfer --threads 1  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "output",
   "lfn": "mvt_MaxVelocity_20170329-074254.geojson",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///srv/mvt_MaxVelocity_20170329-074254.geojson", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "staging", "url": "scp://panorama@10.100.101.107/home/panorama/public_html//panorama/pegasus/casa-wind/run0015/00/00/mvt_MaxVelocity_20170329-074254.geojson" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "output",
   "lfn": "MaxVelocity_20170329-074254.png",
   "id": 2,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///srv/MaxVelocity_20170329-074254.png", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "staging", "url": "scp://panorama@10.100.101.107/home/panorama/public_html//panorama/pegasus/casa-wind/run0015/00/00/MaxVelocity_20170329-074254.png" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "output",
   "lfn": "alert_20170329-074254.geojson",
   "id": 3,
   "src_urls": [
     { "site_label": "condorpool", "url": "file:///srv/alert_20170329-074254.geojson", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "staging", "url": "scp://panorama@10.100.101.107/home/panorama/public_html//panorama/pegasus/casa-wind/run0015/00/00/alert_20170329-074254.geojson" }
   ] }
]
eof

printf "\n################[Container] Exiting pegasus lite container script ################\n"  1>&2
EOF2


chmod +x merge_bottom-cont.sh
if ! [ $pegasus_lite_start_dir -ef . ]; then
	cp $pegasus_lite_start_dir/pegasus-lite-common.sh . 
fi

set +e
singularity_init casa_wind_cont.sif
job_ec=$(($job_ec + $?))

singularity exec --no-home --bind $PWD:/srv --bind /home/panorama/public_html:/home/panorama/public_html:ro casa_wind_cont.sif /srv/merge_bottom-cont.sh 
job_ec=$(($job_ec + $?))


set -e


# clear the trap, and exit cleanly
trap - EXIT
pegasus_lite_final_exit

